using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MarketCore.WPF.Models.PregaoVivaVoz;

namespace MarketCore.WPF.Services.PregaoVivaVoz
{
    /// <summary>
    /// MOTOR PRINCIPAL do Pregão Viva Voz.
    ///
    /// PADRÃO: Event Bridge
    /// - Expõe métodos públicos que qualquer código pode chamar
    /// - Não conhece diretamente o ProfitDLL nem o Simulator
    /// - O MarketCore chama estes métodos quando eventos chegam
    /// - Zero acoplamento com estruturas internas
    ///
    /// FLUXO:
    /// 1. MarketCore recebe callback do ProfitDLL (ou Simulator)
    /// 2. MarketCore chama: engine.ProcessarAgressao("goldman", "compra", 500)
    /// 3. Engine agrega callbacks em blocos → verifica filtros → narra via FraseBuilder → AudioPlayback
    /// 4. AudioPlayback toca (ou loga no console se sem WAV)
    ///
    /// AGREGAÇÃO (v2):
    /// CASO 1 — Bloco simultâneo: callbacks com gap ≤ JanelaMilissegundos agrupados,
    ///          narrados uma única vez com total agregado ("bateu/tomou [total]").
    /// CASO 2 — Sequência progressiva (players com Rajada.Participa=true):
    ///          "batendo/tomando" no início, checkpoint a cada SequenciaMinima blocos,
    ///          "parou de bater/tomar" após silêncio de SilencioParouMilissegundos.
    /// </summary>
    public class PregaoVivaVozEngine : IDisposable
    {
        private readonly Dictionary<string, PlayerConfig> _playersConfig = new();
        private readonly ConfigRajadaGlobal _configRajada;
        private readonly FraseBuilderService _fraseBuilder;
        private readonly AudioPlaybackService _audioPlayback;
        private readonly DetectorRajadaService _detectorRajada;

        private bool _iniciado = false;
        private bool _pausado = false;

        // Estatísticas
        private int _eventosProcessados = 0;
        private int _eventosNarrados = 0;
        private int _rajadasDetectadas = 0;

        // ============ AGREGADOR DE BLOCOS ============

        /// <summary>
        /// Estado de agregação por player+lado. Chave: "playerChave|lado".
        /// </summary>
        private readonly ConcurrentDictionary<string, EstadoAgressao> _estadosAgressao = new();

        /// <summary>
        /// Timer que faz polling a cada 20ms para:
        /// 1. Fechar blocos cujo gap excedeu JanelaMilissegundos (narrar total agregado)
        /// 2. Detectar silêncio > SilencioParouMilissegundos (narrar "parou de bater/tomar")
        /// </summary>
        private Timer? _agregadorTimer;

        /// <summary>
        /// Estado de agregação por player+direção.
        /// Rastreia bloco simultâneo (CASO 1) e sequência progressiva (CASO 2).
        /// </summary>
        private class EstadoAgressao
        {
            public string PlayerChave = "";
            public string PlayerNome = "";
            public string Lado = ""; // "compra" ou "venda"

            // --- Bloco simultâneo (CASO 1) ---
            /// <summary>Volume acumulado do bloco aberto.</summary>
            public int VolumeBloco;
            /// <summary>UTC Ticks do último callback recebido.</summary>
            public long TicksUltimoCallback;
            /// <summary>Se há um bloco aberto aguardando mais callbacks.</summary>
            public bool BlocoAberto;

            // --- Sequência progressiva (CASO 2, só rajada) ---
            /// <summary>Se uma sequência "batendo/tomando" está em andamento.</summary>
            public bool SequenciaAtiva;
            /// <summary>Blocos fechados desde o último checkpoint.</summary>
            public int ContadorBlocos;
            /// <summary>Volume acumulado desde o último checkpoint.</summary>
            public int VolumeDesdeMarco;
        }

        // ============ EVENTOS PÚBLICOS ============

        /// <summary>
        /// Disparado quando um evento é NARRADO (passou nos filtros).
        /// </summary>
        /// <summary>
        /// Disparado quando uma narração termina de tocar. Payload traz texto + callback
        /// original que a gerou (para correlação perfeita no log).
        /// </summary>
        public event EventHandler<NarracaoInfo>? EventoNarrado;

        /// <summary>
        /// Disparado com estatísticas periódicas.
        /// </summary>
        public event EventHandler<string>? EstatisticasAtualizadas;

        // ============ PROPRIEDADES ============

        public bool Pausado
        {
            get => _pausado;
            set
            {
                _pausado = value;
                _audioPlayback.Pausado = value;
                if (value)
                {
                    _audioPlayback.LimparFila();
                    _estadosAgressao.Clear();
                }
            }
        }

        /// <summary>
        /// Retorna true se o motor está ativo (Iniciar() foi chamado E não está pausado).
        /// Usado pelo ProfitDLLBridge para descartar eventos quando o motor não está ativo.
        /// </summary>
        public bool MotorAtivo => _iniciado && !_pausado;

        public int VolumeMaster
        {
            get => _audioPlayback.VolumeMaster;
            set => _audioPlayback.VolumeMaster = value;
        }

        public int EventosProcessados => _eventosProcessados;
        public int EventosNarrados => _eventosNarrados;
        public int RajadasDetectadas => _rajadasDetectadas;

        // ============ CONSTRUTOR ============

        public PregaoVivaVozEngine(
            List<PlayerConfig> players,
            ConfigRajadaGlobal configRajada,
            string diretorioAudio)
        {
            _configRajada = configRajada ?? new ConfigRajadaGlobal();

            // Indexar players por chave pra lookup rápido
            foreach (var p in players)
            {
                _playersConfig[p.Chave.ToLower()] = p;
            }

            // Serviços dependentes
            _fraseBuilder = new FraseBuilderService(diretorioAudio);
            _audioPlayback = new AudioPlaybackService();
            _detectorRajada = new DetectorRajadaService(_configRajada);

            // Conecta eventos do detector (mantidos por compatibilidade)
            _detectorRajada.RajadaIniciada += OnRajadaIniciada;
            _detectorRajada.RajadaParou += OnRajadaParou;

            // Conecta eventos do playback
            _audioPlayback.ItemReproduzido += (s, info) => EventoNarrado?.Invoke(this, info);
        }

        // ============ CONTROLE ============

        public void Iniciar()
        {
            if (_iniciado) return;
            _iniciado = true;
            _pausado = false;

            _audioPlayback.Iniciar();
            _detectorRajada.Iniciar();

            // Timer do agregador: poll a cada 20ms pra fechar blocos e detectar silêncio
            _agregadorTimer = new Timer(PollAgregador, null, 20, 20);

            Console.WriteLine($"[PregaoVivaVozEngine] Motor iniciado com {_playersConfig.Count} players configurados");
            EstatisticasAtualizadas?.Invoke(this, $"Motor iniciado · {_playersConfig.Count} players");
        }

        public void Parar()
        {
            _iniciado = false;
            _pausado = true;
            _audioPlayback.LimparFila();
            _agregadorTimer?.Change(Timeout.Infinite, Timeout.Infinite);
            _estadosAgressao.Clear();
            Console.WriteLine("[PregaoVivaVozEngine] Motor parado");
        }

        /// <summary>
        /// Atualiza configuração de um player em tempo real.
        /// Chame quando o usuário mudar limites na UI.
        /// </summary>
        public void AtualizarPlayer(PlayerConfig player)
        {
            if (player == null) return;
            _playersConfig[player.Chave.ToLower()] = player;
        }

        // ============ EVENT BRIDGE - MÉTODOS PÚBLICOS ============
        // Estes são os métodos que o MarketCore chama depois da integração

        /// <summary>
        /// PROCESSA UM TRADE (agressão).
        /// Chame para CADA trade que chegar do ProfitDLL.
        ///
        /// v2: agrega callbacks em blocos simultâneos (CASO 1) e detecta
        /// sequências progressivas (CASO 2) em vez de narrar individualmente.
        /// O filtro de volume por player é aplicado no fechamento do bloco.
        ///
        /// Parâmetros:
        /// - nomeCorretora: nome exato como vem do ProfitDLL (ex: "Goldman", "JPM")
        /// - lado: "compra" (agressão de compra/tomou) ou "venda" (agressão de venda/bateu)
        /// - quantidade: número de contratos
        /// </summary>
        public void ProcessarAgressao(string nomeCorretora, string lado, int quantidade, string? callbackInfo = null)
        {
            if (_pausado || string.IsNullOrEmpty(nomeCorretora)) return;

            _eventosProcessados++;

            // Identificar o player
            var player = IdentificarPlayer(nomeCorretora);
            if (player == null || !player.AtivoHoje) return;

            // Verificar se agressão está ativa para este player
            if (!player.Agressao.Ativo) return;

            // Alimenta o agregador — filtro de volume aplicado no fechamento do bloco
            AlimentarAgregador(player, lado, quantidade);
        }

        /// <summary>
        /// PROCESSA UMA ORDEM NO BOOK (ordem passiva colocada).
        ///
        /// Parâmetros:
        /// - nomeCorretora: nome da corretora
        /// - lado: "compra" (ordem de compra no bid) ou "venda" (ordem de venda no ask)
        /// - nivel: 1 = boca (L1), 2 a 5 = níveis mais afastados
        /// - quantidade: contratos ofertados
        /// </summary>
        public void ProcessarBook(string nomeCorretora, string lado, int nivel, int quantidade, string? callbackInfo = null)
        {
            if (_pausado || string.IsNullOrEmpty(nomeCorretora)) return;

            _eventosProcessados++;

            var player = IdentificarPlayer(nomeCorretora);
            if (player == null || !player.AtivoHoje) return;

            if (!player.Book.Ativo) return;

            int limiteMinimo = lado == "compra"
                ? player.Book.CompraMinima
                : player.Book.VendaMinima;

            if (quantidade < limiteMinimo) return;

            var tipo = lado == "compra" ? TipoEvento.BookCompra : TipoEvento.BookVenda;
            var evento = new EventoOrderFlow
            {
                Timestamp = DateTime.Now,
                PlayerChave = player.Chave,
                PlayerNome = player.Nome,
                Tipo = tipo,
                Quantidade = quantidade,
                Nivel = Math.Clamp(nivel, 1, 4)
            };

            NarrarEvento(evento, callbackInfo);
        }

        /// <summary>
        /// PROCESSA UM TRADE EXECUTADO (versão simplificada de agressão).
        /// Use se você só tem info de que houve trade, sem saber se foi agressão ou passivo.
        /// </summary>
        public void ProcessarTrade(string nomeCorretora, string lado, int quantidade)
        {
            // Por padrão, trata como agressão
            ProcessarAgressao(nomeCorretora, lado, quantidade);
        }

        // ============ AGREGADOR DE BLOCOS E SEQUÊNCIAS ============

        /// <summary>
        /// Alimenta o estado de agregação com um novo callback.
        /// Se o bloco anterior já expirou (gap > EmAteMs), fecha-o antes de iniciar um novo.
        /// Para players com Rajada.Participa=true, o primeiro bloco inicia uma sequência
        /// progressiva e narra "batendo/tomando" imediatamente.
        /// </summary>
        private void AlimentarAgregador(PlayerConfig player, string lado, int quantidade)
        {
            var chaveEstado = string.Concat(player.Chave, "|", lado);
            var agora = DateTime.UtcNow.Ticks;
            long emAteTicks = (long)_configRajada.JanelaMilissegundos * TimeSpan.TicksPerMillisecond;

            var estado = _estadosAgressao.GetOrAdd(chaveEstado, _ => new EstadoAgressao
            {
                PlayerChave = player.Chave,
                PlayerNome = player.Nome,
                Lado = lado
            });

            lock (estado)
            {
                estado.PlayerNome = player.Nome; // refresh caso tenha mudado

                if (estado.BlocoAberto)
                {
                    long gap = agora - estado.TicksUltimoCallback;
                    if (gap <= emAteTicks)
                    {
                        // Dentro do EmAteMs → agregar no bloco atual
                        estado.VolumeBloco += quantidade;
                        estado.TicksUltimoCallback = agora;
                        return;
                    }

                    // Gap > EmAteMs → fechar bloco anterior, depois iniciar novo
                    FecharBloco(estado, player);
                }

                // Iniciar novo bloco
                estado.VolumeBloco = quantidade;
                estado.TicksUltimoCallback = agora;
                estado.BlocoAberto = true;

                // CASO 2: primeiro bloco de rajada → narrar "batendo/tomando"
                if (player.Rajada.Participa && !estado.SequenciaAtiva)
                {
                    estado.SequenciaAtiva = true;
                    Interlocked.Increment(ref _rajadasDetectadas);

                    var tipoInicio = lado == "compra"
                        ? TipoEvento.RajadaInicioCompra
                        : TipoEvento.RajadaInicioVenda;

                    NarrarEvento(new EventoOrderFlow
                    {
                        Timestamp = DateTime.Now,
                        PlayerChave = player.Chave,
                        PlayerNome = player.Nome,
                        Tipo = tipoInicio,
                        Quantidade = 0
                    }, "SEQUENCIA_INICIO");

                    Console.WriteLine($"[SEQ INICIO] {player.Nome} {lado}");
                }
            }
        }

        /// <summary>
        /// Fecha bloco aberto e processa volume agregado.
        ///
        /// CASO 1 (não-rajada): narra "bateu/tomou [total]" se filtro por player OK.
        /// CASO 2 (rajada): incrementa contador de blocos, acumula volume.
        ///   Ao atingir SequenciaMinima blocos, narra checkpoint com volume acumulado.
        ///
        /// DEVE ser chamado dentro de lock(estado).
        /// </summary>
        private void FecharBloco(EstadoAgressao estado, PlayerConfig player)
        {
            if (!estado.BlocoAberto || estado.VolumeBloco == 0) return;

            int volumeBloco = estado.VolumeBloco;
            estado.BlocoAberto = false;
            estado.VolumeBloco = 0;

            if (!player.Rajada.Participa)
            {
                // ── CASO 1: narrar "bateu/tomou [total]" com filtro por player ──
                int limiteMinimo = estado.Lado == "compra"
                    ? player.Agressao.TomouMinimo
                    : player.Agressao.BateuMinimo;

                if (volumeBloco >= limiteMinimo)
                {
                    var tipo = estado.Lado == "compra"
                        ? TipoEvento.AgressaoCompra
                        : TipoEvento.AgressaoVenda;

                    NarrarEvento(new EventoOrderFlow
                    {
                        Timestamp = DateTime.Now,
                        PlayerChave = player.Chave,
                        PlayerNome = player.Nome,
                        Tipo = tipo,
                        Quantidade = volumeBloco
                    }, $"BLOCO_AGREGADO (vol={volumeBloco})");
                }
                return;
            }

            // ── CASO 2: acumular para checkpoint ──
            estado.VolumeDesdeMarco += volumeBloco;
            estado.ContadorBlocos++;

            if (estado.ContadorBlocos >= _configRajada.SequenciaMinima)
            {
                // Checkpoint: narrar acumulado se passa nos filtros
                int limiteMinimo = estado.Lado == "compra"
                    ? player.Agressao.TomouMinimo
                    : player.Agressao.BateuMinimo;

                if (estado.VolumeDesdeMarco >= _configRajada.VolumeMinimo &&
                    estado.VolumeDesdeMarco >= limiteMinimo)
                {
                    var tipo = estado.Lado == "compra"
                        ? TipoEvento.AgressaoCompra
                        : TipoEvento.AgressaoVenda;

                    NarrarEvento(new EventoOrderFlow
                    {
                        Timestamp = DateTime.Now,
                        PlayerChave = player.Chave,
                        PlayerNome = player.Nome,
                        Tipo = tipo,
                        Quantidade = estado.VolumeDesdeMarco
                    }, $"SEQUENCIA_CHECKPOINT (blocos={estado.ContadorBlocos}, vol={estado.VolumeDesdeMarco})");

                    Console.WriteLine($"[SEQ CHECKPOINT] {player.Nome} {estado.Lado} · {estado.ContadorBlocos} blocos · vol {estado.VolumeDesdeMarco}");
                }

                // Reset contadores (mesmo se não narrou por filtro)
                estado.ContadorBlocos = 0;
                estado.VolumeDesdeMarco = 0;
            }
        }

        /// <summary>
        /// Timer callback (20ms). Percorre todos os estados de agregação para:
        /// 1. Fechar blocos cujo gap excedeu JanelaMilissegundos (EmAteMs)
        /// 2. Detectar silêncio > SilencioParouMilissegundos → narrar "parou" + resetar
        /// </summary>
        private void PollAgregador(object? state)
        {
            if (_pausado) return;

            var agora = DateTime.UtcNow.Ticks;
            long emAteTicks = (long)_configRajada.JanelaMilissegundos * TimeSpan.TicksPerMillisecond;
            long parouTicks = (long)_configRajada.SilencioParouMilissegundos * TimeSpan.TicksPerMillisecond;

            foreach (var kvp in _estadosAgressao)
            {
                var estado = kvp.Value;

                lock (estado)
                {
                    long gap = agora - estado.TicksUltimoCallback;

                    // 1. Fechar bloco aberto se gap > EmAteMs
                    if (estado.BlocoAberto && gap > emAteTicks)
                    {
                        if (_playersConfig.TryGetValue(estado.PlayerChave, out var playerBloco))
                        {
                            FecharBloco(estado, playerBloco);
                        }
                        else
                        {
                            // Player removido — limpar bloco sem narrar
                            estado.BlocoAberto = false;
                            estado.VolumeBloco = 0;
                        }
                    }

                    // 2. Detectar "parou" se sequência ativa, bloco fechado, e silêncio > ParouAposMs
                    if (estado.SequenciaAtiva && !estado.BlocoAberto && gap > parouTicks)
                    {
                        // Narrar volume restante (blocos < SequenciaMinima que não atingiram checkpoint)
                        if (estado.VolumeDesdeMarco > 0 &&
                            _playersConfig.TryGetValue(estado.PlayerChave, out var playerParou))
                        {
                            int limiteMinimo = estado.Lado == "compra"
                                ? playerParou.Agressao.TomouMinimo
                                : playerParou.Agressao.BateuMinimo;

                            if (estado.VolumeDesdeMarco >= limiteMinimo)
                            {
                                var tipo = estado.Lado == "compra"
                                    ? TipoEvento.AgressaoCompra
                                    : TipoEvento.AgressaoVenda;

                                NarrarEvento(new EventoOrderFlow
                                {
                                    Timestamp = DateTime.Now,
                                    PlayerChave = estado.PlayerChave,
                                    PlayerNome = estado.PlayerNome,
                                    Tipo = tipo,
                                    Quantidade = estado.VolumeDesdeMarco
                                }, $"SEQUENCIA_FINAL_RESTANTE (vol={estado.VolumeDesdeMarco})");
                            }
                        }

                        // Narrar "parou de bater/tomar"
                        var tipoParou = estado.Lado == "compra"
                            ? TipoEvento.RajadaPararCompra
                            : TipoEvento.RajadaPararVenda;

                        NarrarEvento(new EventoOrderFlow
                        {
                            Timestamp = DateTime.Now,
                            PlayerChave = estado.PlayerChave,
                            PlayerNome = estado.PlayerNome,
                            Tipo = tipoParou,
                            Quantidade = 0
                        }, "SEQUENCIA_PAROU (timeout de silencio)");

                        Console.WriteLine($"[SEQ PAROU] {estado.PlayerNome} {estado.Lado}");

                        // Reset completo
                        estado.SequenciaAtiva = false;
                        estado.ContadorBlocos = 0;
                        estado.VolumeDesdeMarco = 0;
                    }
                }
            }
        }

        // ============ INTERNAL - NARRAÇÃO ============

        /// <summary>
        /// Envia um evento pro FraseBuilder e enfileira no AudioPlayback.
        /// <paramref name="callbackInfo"/> é a string original do callback da DLL — viaja
        /// junto do evento até o log de narração pra manter correlação perfeita.
        /// </summary>
        private void NarrarEvento(EventoOrderFlow evento, string? callbackInfo = null)
        {
            var arquivos = _fraseBuilder.MontarFrase(evento);
            var textoTextual = _fraseBuilder.MontarFraseTextual(evento);

            if (arquivos.Count == 0) return;

            _audioPlayback.Enfileirar(arquivos, textoTextual, callbackInfo);
            _eventosNarrados++;

            Console.WriteLine($"[NARRAR] {textoTextual}");
        }

        // ============ HANDLERS DE RAJADA (compatibilidade) ============
        // Mantidos para compatibilidade com DetectorRajadaService.
        // Na v2, a detecção de sequências é feita pelo agregador acima.
        // Estes handlers só disparam se alguém chamar RegistrarAgressao diretamente.

        private void OnRajadaIniciada(object? sender, EventoOrderFlow evento)
        {
            _rajadasDetectadas++;

            // Enriquece o nome do player
            var player = _playersConfig.Values.FirstOrDefault(p => p.Chave == evento.PlayerChave);
            if (player != null)
            {
                evento.PlayerNome = player.Nome;
            }

            NarrarEvento(evento, "RAJADA_INICIO (derivado de multiplas agressoes)");
        }

        private void OnRajadaParou(object? sender, EventoOrderFlow evento)
        {
            var player = _playersConfig.Values.FirstOrDefault(p => p.Chave == evento.PlayerChave);
            if (player != null)
            {
                evento.PlayerNome = player.Nome;
            }

            NarrarEvento(evento, "RAJADA_PAROU (timeout de silencio)");
        }

        // ============ HELPERS ============

        /// <summary>
        /// Identifica o player a partir do nome que vem do ProfitDLL.
        /// Faz match tanto pelo nome completo quanto por variações.
        /// </summary>
        private PlayerConfig? IdentificarPlayer(string nomeCorretora)
        {
            if (string.IsNullOrEmpty(nomeCorretora)) return null;

            var nomeNorm = nomeCorretora.Trim().ToLower();

            // Match direto por chave
            if (_playersConfig.TryGetValue(nomeNorm, out var player))
                return player;

            // Match por nome exato
            foreach (var p in _playersConfig.Values)
            {
                if (p.Nome.Equals(nomeCorretora, StringComparison.OrdinalIgnoreCase))
                    return p;

                if (p.Codigo.Equals(nomeCorretora, StringComparison.OrdinalIgnoreCase))
                    return p;
            }

            // Match parcial (contém)
            foreach (var p in _playersConfig.Values)
            {
                if (nomeNorm.Contains(p.Chave.ToLower()) ||
                    p.Nome.ToLower().Contains(nomeNorm))
                    return p;
            }

            return null;
        }

        public void Dispose()
        {
            _agregadorTimer?.Dispose();
            _audioPlayback?.Dispose();
            _detectorRajada?.Dispose();
        }
    }
}
